#
import sys
from socket import *

   
class WebServer:
    def start(port):
        print(f"Starting serevr on port {port}")
        ## NEEDS IMPLEMENTATION
        ## You have to understand how sockets work and how to program them.
        ## A good starting point is the socket tutorial from the PyDocs
        ## https://docs.python.org/3.7/howto/sockets.html
        ##
        ## Hints
        ## 1. You should set up the socket(s) and then call handleClientSocket


    def handleClientSocket(client):
        """
        Handles requests sent by client
        :param client: Socket that handles the client connection
        """
        ## NEEDS IMPLEMENTATION
        ## This function is supposed to handle the request
        ## (1) Read the request from the socket 
        ## (2) Parse the request headers to a HttpRequest class
        ## (3) Form a response using formHttpResponse.
        ## (4) Send a response using sendHttpResponse.        
        

    def sendHttpResponse(client, response):
        """
        Sends a response back to the client
        :param client: Socket that handles the client connection
        :param response: the response that should be send to the client
        """
        # NEEDS IMPLEMENTATION


    def formHttpResponse(request):
        """
        Form a response to an HttpRequest
        :param request: the HTTP request
        :return: a byte[] that contains the data that should be send to the client
        """
        ##  NEEDS IMPLEMENTATION
        ##  Make sure you follow the (modified) HTTP specification
        ##  in the assignment regarding header fields and newlines



class HttpRequest:
    def __init__():
        fields = {}

    ## NEEDS IMPLEMENTATION

    

if __name__ == "__main__":
    try:
        port = int(sys.argv[1])
    except:
        print("Usage: python WebServer.py <port>")
        exit(1)

    server = WebServer()
    server.start(port)
              
